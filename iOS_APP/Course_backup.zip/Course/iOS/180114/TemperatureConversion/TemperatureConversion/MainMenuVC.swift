//
//  MainMenuVC.swift
//  TemperatureConversion
//
//  Created by cycu on 2018/1/14.
//  Copyright © 2018年 IOS Class. All rights reserved.
//

import UIKit

class MainMenuVC: UIViewController {

    //@IBOutlet weak var temperature: UIImageView!
    //@IBOutlet weak var lbkg: UIImageView!
    //@IBOutlet weak var scale: UIImageView!
    //@IBOutlet weak var calsulator: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //temperature.image = UIImage(named: "temperature.png")
        //lbkg.image = UIImage(named: "lb-kg.jpg")
        //scale.image = UIImage(named: "scale.png")
        //calsulator.image = UIImage(named: "calculator.jpg")
        
        // Do any additional setup after loading the view.
        
    }
}
